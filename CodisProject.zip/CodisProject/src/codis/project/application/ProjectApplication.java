package codis.project.application;

import java.util.HashMap;
import java.util.Scanner;

import codis.project.application.helper.AddressHelper;
import codis.project.application.helper.PersonHelper;

public class ProjectApplication {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		while (true) {

			String getInput = sc.nextLine();

			if (getInput.equals("exit")) {
				sc.close();
				System.exit(0);
			}

			String[] commands = getInput.split(" ");

			String data = "";

			if (commands.length > 2)

				for (int i = 2; i < commands.length; i++) {
					data += commands[i] + " ";
				}

			String[] keyValues = data.split("-");

			HashMap<String, String> propertyValues = new HashMap<>();

			if (keyValues.length > 1) {
				for (int i = 1; i < keyValues.length; i++) {

					String[] keyValue = PersonHelper.getKeyValue(keyValues[i]);

					propertyValues.put(keyValue[0], keyValue[1]);
				}

			}

			if (commands.length == 1) {
				if (commands[0].equals("help"))
					System.out.println("Commands :\nperson command|commands\naddress command|commands\nhelp");
				else
					System.out.println("Invalid command, for commands list please enter help");
			}

			if (commands.length > 1) {
				switch (commands[0]) {

				case "person":
					switch (commands[1]) {

					case "view":
						if (commands.length == 2)
							PersonHelper.viewAllPersons();
						else
							PersonHelper.viewPerson(propertyValues);
						break;

					case "add":
						PersonHelper.addPerson(propertyValues);
						break;

					case "delete":
						PersonHelper.deletePerson(propertyValues);
						break;

					case "edit":
						PersonHelper.editPerson(propertyValues);
						break;

					case "search":
						if (commands.length == 3) {

							String searchText = commands[2];

							searchText = searchText.replaceAll("�", "");
							searchText = searchText.replaceAll("�", "");
							searchText = searchText.replaceAll("\"", "");

							PersonHelper.searchAndDisplayPersons(PersonHelper.searchPerson(searchText), searchText);
						} else
							System.out.println("Invalid search text\nSyntax :person search \"SearchString\"");
						break;

					default:
						System.out.println("Invalid command \nValid commands add / view / edit / delete / search");
					}
					break;

				case "address":
					switch (commands[1]) {

					case "add":
						AddressHelper.addAddress(propertyValues);
						break;

					case "view":
						if (commands.length == 2)
							AddressHelper.viewAllAddress(propertyValues);
						else
							AddressHelper.viewAddress(propertyValues);
						break;

					case "edit":
						AddressHelper.editAddress(propertyValues);
						break;

					case "delete":
						AddressHelper.deleteAddress(propertyValues);
						break;

					default:
						System.out.println("Invalid command \nValid commands add / view / edit / delete / search");
					}
					break;

				case "help":
					System.out.println("Commands :\nperson command|commands\naddress command|commands\nhelp");
					break;

				default:
					System.out.println("Invalid command, for commands list please enter help");
				}
			}
		}
	}
}