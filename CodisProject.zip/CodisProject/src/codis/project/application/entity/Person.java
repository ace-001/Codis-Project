package codis.project.application.entity;

/**
 * Person entity class
 * 
 * Field Constraints ID Unique, can be text or numeric First Name Required,
 * cannot contain numbers Last Name Required, cannot contain numbers Date of
 * Birth Required Nickname Cannot contain numbers
 * 
 * @author Poornapragnya
 */
public class Person {

	private String id;

	private String firstName;

	private String lastName;

	private String dateOfBirth;

	private String nickName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

}
