package codis.project.application.helper;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import codis.project.application.entity.Address;

public class AddressHelper {

	private static String[] countries = { "Albania", "Latvia", "Andorra", "Liechtenstein", "Armenia", "Lithuania",
			"Austria", "Luxembourg", "Azerbaijan", "Malta", "Belarus", "Moldova", "Belgium", "Monaco",
			"Bosnia and Herzegovina", "Montenegro", "Bulgaria", "Netherlands", "Croatia", "Norway", "Cyprus", "Poland",
			"Czech Republic", "Portugal", "Denmark", "Romania", "Estonia", "Russia", "Finland", "San Marino",
			"Macedonia", "Serbia", "France", "Slovakia", "Georgia", "Slovenia", "Germany", "Spain", "Greece", "Sweden",
			"Hungary", "Sweden", "Iceland", "Switzerland", "Ireland", "Turkey", "Italy", "Ukraine", "Kosovo",
			"United Kingdom" };

	private static List<String> europianCountries = Arrays.asList(countries);

	public static void addAddress(HashMap<String, String> propertyValues) {

//		List<HashMap<String, Object>> assa = new ArrayList<>();

		Address a = new Address();

		enterAddressData(a, propertyValues);

		List<Address> addresses = new ArrayList<>();

		HashMap<String, Object> personAddress = new HashMap<>();

		if (propertyValues.containsKey("personId") && isPersonIdPresent(propertyValues.get("personId"))) {

			if (!europianCountries.contains(propertyValues.get("country"))) {
				System.out.println("\nInvalid country name\nMust be a valid country in Europe");
				return;
			}

			String id = propertyValues.get("personId");

			try {

				JsonArray array = getAddressList();

				Gson gson = new GsonBuilder().setPrettyPrinting().create();

				JsonArray newArray = new JsonArray();

				JsonParser jsonParser = new JsonParser();

				boolean found = false;

				String addressId = "0";

				if (array.size() != 0) {

					for (JsonElement e : array) {

						JsonObject aa = (JsonObject) e;

						JsonArray addressArray = (JsonArray) aa.get("address");

						if (addressArray.size() != 0)
							addressId = ((JsonObject) addressArray.get(addressArray.size() - 1)).get("id").toString()
									.replaceAll("\"", "");

						if (aa.get("personId").toString().equals("\"" + id + "\"")) {

							found = true;

							setAddressList((JsonArray) aa.get("address"), propertyValues, addresses, a, addressId);

							personAddress.put("personId", id);

							personAddress.put("address", addresses);

							newArray.add(jsonParser.parse(gson.toJson(personAddress)));

						} else {
							newArray.add(e);
						}
					}
				} else {

					a.setId("" + (Integer.parseInt(addressId) + 1));

					found = true;

					addresses.add(a);

					personAddress.put("personId", id);

					personAddress.put("address", addresses);

					newArray.add(jsonParser.parse(gson.toJson(personAddress)));
				}

				if (!found) {

					a.setId("" + (Integer.parseInt(addressId) + 1));

					addresses.add(a);

					personAddress.put("personId", id);

					personAddress.put("address", addresses);

					newArray.add(jsonParser.parse(gson.toJson(personAddress)));
				}

				File file = new File("AddressData.json");
				file.createNewFile();
				FileWriter write = new FileWriter(file);
				write.write(gson.toJson(newArray));
				write.close();

				System.out.println("Addedd Address successfully \nAddress ID " + (Integer.parseInt(addressId) + 1));
			} catch (JsonIOException | IOException e) {
				e.printStackTrace();
			}
		} else
			System.out.println("Person ID not found");
	}

	private static boolean isPersonIdPresent(String id) {

		for (JsonElement person : PersonHelper.getPersonList()) {

			JsonObject obj = (JsonObject) person;

			if (obj.get("id").toString().replaceAll("\"", "").equals(id))
				return true;
		}

		return false;
	}

	private static void setAddressList(JsonArray addressList, HashMap<String, String> propertyValues,
			List<Address> addresses, Address newA, String id) {

		for (JsonElement address : addressList) {

			Address a = new Address();

			JsonObject ad = (JsonObject) address;

			a.setId(ad.get("id").toString().replaceAll("\"", ""));

			a.setLine1(ad.get("line1").toString().replaceAll("\"", ""));

			a.setCountry(ad.get("country").toString().replaceAll("\"", ""));

			if (ad.has("line2"))
				a.setLine2(ad.get("line2").toString().replaceAll("\"", ""));

			if (ad.has("postcode"))
				a.setPostcode(ad.get("postcode").toString().replaceAll("\"", ""));

			addresses.add(a);
		}

		Address a = new Address();

		a.setId("" + (Integer.parseInt(id) + 1));

		a.setLine1(propertyValues.get("line1"));

		a.setCountry(propertyValues.get("country"));

		if (propertyValues.containsKey("line2"))
			a.setLine2(propertyValues.get("line2"));

		if (propertyValues.containsKey("postcode"))
			a.setPostcode(propertyValues.get("postcode"));

		addresses.add(a);
	}

	private static void enterAddressData(Address a, HashMap<String, String> propertyValues) {

		if (propertyValues.containsKey("line1"))
			a.setLine1(propertyValues.get("line1"));

		if (propertyValues.containsKey("line2"))
			a.setLine2(propertyValues.get("line2"));

		if (propertyValues.containsKey("country"))
			a.setCountry(propertyValues.get("country"));

		if (propertyValues.containsKey("postcode"))
			a.setPostcode(propertyValues.get("postcode"));
	}

	public static JsonArray getAddressList() {

		JsonArray list = new JsonArray();

		try {

			JsonParser jsonParser = new JsonParser();

			File file = new File("AddressData.json");
			file.createNewFile();
			FileReader reader = new FileReader(file);
			// Read JSON file
			Object obj = jsonParser.parse(reader);

			if (!(obj instanceof JsonNull))
				list = (JsonArray) obj;

		} catch (JsonIOException | IOException e) {
			e.printStackTrace();
		}

		return list;

	}

	public static void viewAllAddress(HashMap<String, String> propertyValues) {

		JsonArray personList = getAddressList();

		if (personList.size() > 0) {

			personList.forEach(person -> parseAddressObject((JsonObject) person));
		} else {
			System.out.println("No Address data exist");
		}
	}

	private static void parseAddressObject(JsonObject address) {

		String data = address.get("address").toString();

		data = data.replaceAll("[{}\"]", "");
		data = data.replaceAll(",", " \t ");
		data = data.replaceAll(":", " : ");
		data = data.replaceAll("[\\[\\]]", "");

		System.out.println("personId : " + address.get("personId"));

		String[] datadata = data.split("id");

		for (int i = 1; i < datadata.length; i++) {

			System.out.println("id" + datadata[i]);
		}

		System.out.println();
	}

	public static void editAddress(HashMap<String, String> propertyValues) {

		if (propertyValues.containsKey("id")) {

			final String id = propertyValues.get("id");

			JsonArray list = getAddressList();

			JsonArray newList = new JsonArray();

			JsonParser jsonParser = new JsonParser();

			Address a = new Address();

			Gson gson = new GsonBuilder().setPrettyPrinting().create();

			boolean found = false;

			for (JsonElement e : list) {

				JsonObject aa = (JsonObject) e;

				JsonArray addressArray = (JsonArray) aa.get("address");

				JsonArray newArray = new JsonArray();

				for (JsonElement add : addressArray) {

					JsonObject addObj = (JsonObject) add;

					if (addObj.get("id").toString().replaceAll("\"", "").equals(id)) {
						found = true;
						editAddressProperties(addObj, propertyValues, newArray, a);
					} else
						newArray.add(addObj);
				}

				JsonObject object = new JsonObject();

				object.add("personId", jsonParser.parse(aa.get("personId").toString().replaceAll("\"", "")));

				object.add("address", newArray);

				newList.add(object);
			}

			if (found)
				try {
					File file = new File("AddressData.json");
					file.createNewFile();
					FileWriter write = new FileWriter(file);
					write.write(gson.toJson(newList));
					write.close();

					System.out.println("Address detailes edited successfully \nAddress ID : " + a.getId());
				} catch (JsonIOException | IOException e) {
					e.printStackTrace();
				}
			else
				System.out.println("Invalid Address ID : " + id);
		} else
			System.out.println("id field dowsn't exist \nSyntax :address edit -id ID ...");

	}

	private static void editAddressProperties(JsonObject addObj, HashMap<String, String> propertyValues,
			JsonArray newArray, Address a) {

		a.setId(addObj.get("id").toString().replaceAll("\"", ""));

		a.setLine1(addObj.get("line1").toString().replaceAll("\"", ""));

		a.setCountry(addObj.get("country").toString().replaceAll("\"", ""));

		if (addObj.has("line2"))
			a.setLine2(addObj.get("line2").toString().replaceAll("\"", ""));

		if (addObj.has("postcode"))
			a.setPostcode(addObj.get("postcode").toString().replaceAll("\"", ""));

		if (propertyValues.containsKey("line1"))
			a.setLine1(propertyValues.get("line1"));

		if (propertyValues.containsKey("line2"))
			a.setLine2(propertyValues.get("line2"));

		if (propertyValues.containsKey("country"))
			a.setCountry(propertyValues.get("country"));

		if (propertyValues.containsKey("postcode"))
			a.setPostcode(propertyValues.get("postcode"));

		JsonParser jP = new JsonParser();

		Gson g = new GsonBuilder().setPrettyPrinting().create();

		newArray.add(jP.parse(g.toJson(a)));
	}

	public static void deleteAddress(HashMap<String, String> propertyValues) {

		if (propertyValues.containsKey("id")) {

			final String id = propertyValues.get("id");

			JsonArray list = getAddressList();

			JsonArray newList = new JsonArray();

			JsonParser jsonParser = new JsonParser();

			Gson gson = new GsonBuilder().setPrettyPrinting().create();

			boolean found = false;

			for (JsonElement e : list) {

				JsonObject aa = (JsonObject) e;

				JsonArray addressArray = (JsonArray) aa.get("address");

				JsonArray newArray = new JsonArray();

				for (JsonElement add : addressArray) {

					JsonObject addObj = (JsonObject) add;

					if (!(addObj.get("id").toString().replaceAll("\"", "").equals(id)))

						newArray.add(addObj);
					else
						found = true;
				}

				JsonObject object = new JsonObject();

				object.add("personId", jsonParser.parse(aa.get("personId").toString().replaceAll("\"", "")));

				object.add("address", newArray);

				newList.add(object);
			}

			if (found)
				try {
					File file = new File("AddressData.json");
					file.createNewFile();
					FileWriter write = new FileWriter(file);
					write.write(gson.toJson(newList));
					write.close();

					System.out.println("Address Deleted successfully");
				} catch (JsonIOException | IOException e) {
					e.printStackTrace();
				}
			else
				System.out.println("Invalid Address ID : " + id);
		} else
			System.out.println("id field dowsn't exist \nSyntax :address delete -id ID");
	}

	public static void viewAddress(HashMap<String, String> propertyValues) {

		if (propertyValues.containsKey("id")) {

			final String id = propertyValues.get("id");

			JsonArray list = getAddressList();

			boolean found = false;

			for (JsonElement e : list) {

				JsonObject aa = (JsonObject) e;

				JsonArray addressArray = (JsonArray) aa.get("address");

				for (JsonElement add : addressArray) {

					JsonObject addObj = (JsonObject) add;

					if (addObj.get("id").toString().replaceAll("\"", "").equals(id)) {

						found = true;

						JsonObject o = new JsonObject();

						o.add("personId", aa.get("personId"));

						o.add("address", addObj);

						String data = o.toString();

						data = data.replaceAll("[{}\"]", "");
						data = data.replaceAll(",", " \t ");
						data = data.replaceAll(":", " : ");
						data = data.replaceAll("[\\[\\]]", "");

						System.out.println(data);
					}
				}
			}

			if (!found)
				System.out.println("Invalid Address ID : " + id);
		} else
			System.out.println("id field dowsn't exist \nSyntax :address view -id ID");

	}

}
