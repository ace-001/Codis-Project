package codis.project.application.helper;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import codis.project.application.entity.Address;
import codis.project.application.entity.Person;

/**
 * Class with functions that helps to perform operations like adding, deleting,
 * editing, viewing and search in the Persons data.
 * 
 * @author Poornapragnya
 *
 */
public class PersonHelper {

	/**
	 * adding person data
	 * 
	 * @param propertyValues
	 */
	public static void addPerson(HashMap<String, String> propertyValues) {

		Person p = new Person();

		enterValue(propertyValues, p);

		boolean[] validation = validEntry(p);

		if (!validation[1])
			System.out.println("Invalid First Name or First Name is not entered!");
		if (!validation[2])
			System.out.println("Invalid Last Name or Last Name is not entered!");
		if (!validation[3])
			System.out.println("Invalid Date of birth format (dd/mm/yyyy) or Date of birth is not entered!");

		boolean[] name = { searchPerson(p.getFirstName()).size() == 0, searchPerson(p.getLastName()).size() == 0 };

		if (name[0] && name[1]) {
			if (validation[1] && validation[2] && validation[3] && validation[4]) {
				try {

					Gson gson = new GsonBuilder().setPrettyPrinting().create();

					File file = new File("PersonsData.json");
					file.createNewFile();
					JsonParser jsonParser = new JsonParser();

					JsonArray personList = getPersonList();

					personList.add(jsonParser.parse(gson.toJson(p)));

					FileWriter write = new FileWriter(file);
					write.write(gson.toJson(personList));
					write.close();

					System.out.println("Person added successfully \nPerson ID : " + p.getId());

				} catch (JsonIOException | IOException e) {
					e.printStackTrace();
				}
			}
		} else {
			if (!name[0] && !name[1])
				System.out.println("Person with given first name or last name already exists");
			else if (!name[0])
				System.out.println("Person with given first name already exists");
			else if (!name[1])
				System.out.println("Person with given last name already exists");
		}
	}

	/**
	 * deleting person data
	 * 
	 * @param propertyValues
	 */
	public static void deletePerson(HashMap<String, String> propertyValues) {

		if (propertyValues.containsKey("id")) {
			final String id = propertyValues.get("id");

			JsonArray list = getPersonList();

			int count = list.size();

			JsonArray newList = new JsonArray();

			list.forEach(person -> {

				JsonObject p = (JsonObject) person;

				if (!p.get("id").toString().equals("\"" + id + "\""))
					newList.add(person);
			});

			if (count - 1 == newList.size())
				try {
					Gson gson = new GsonBuilder().setPrettyPrinting().create();
					File file = new File("PersonsData.json");
					file.createNewFile();
					FileWriter write = new FileWriter(file);
					write.write(gson.toJson(newList));
					write.close();

					System.out.println("Person deleted successfully \nPerson ID : " + id);
				} catch (JsonIOException | IOException e) {
					e.printStackTrace();
				}
			else
				System.out.println("Invalid Person ID : " + id);
		} else
			System.out.println("id field dowsn't exist \nSyntax :person delete -id ID");
	}

	/**
	 * editing person data
	 * 
	 * @param propertyValues
	 */
	public static void editPerson(HashMap<String, String> propertyValues) {

		if (propertyValues.containsKey("id")) {

			final String id = propertyValues.get("id");

			JsonArray list = getPersonList();

			int count = list.size();

			JsonArray newList = new JsonArray();

			Person p = new Person();

			Gson gson = new GsonBuilder().setPrettyPrinting().create();

			list.forEach(person -> {

				JsonObject personObject = (JsonObject) person;

				if (personObject.get("id").toString().equals("\"" + id + "\"")) {

					enterEditedValue(propertyValues, personObject, p);

					JsonParser jsonParser = new JsonParser();

					newList.add(jsonParser.parse(gson.toJson(p)));

				} else
					newList.add(person);
			});

			if (count == newList.size())
				try {

					File file = new File("PersonsData.json");
					file.createNewFile();
					FileWriter write = new FileWriter(file);
					write.write(gson.toJson(newList));
					write.close();

					System.out.println("Person detailes edited successfully \nPerson ID : " + p.getId());
				} catch (JsonIOException | IOException e) {
					e.printStackTrace();
				}
			else
				System.out.println("Invalid Person ID : " + id);
		} else
			System.out.println("id field dowsn't exist \nSyntax :person edit -id ID -firstname FirstName...");
	}

	/**
	 * function to help edit and update person data
	 * 
	 * @param propertyValues
	 * @param person
	 * @param p
	 */
	public static void enterEditedValue(HashMap<String, String> propertyValues, JsonObject person, Person p) {

		p.setId(person.get("id").toString().replaceAll("\"", ""));

		p.setFirstName(person.get("firstName").toString().replaceAll("\"", ""));

		p.setLastName(person.get("lastName").toString().replaceAll("\"", ""));

		p.setDateOfBirth(person.get("dateOfBirth").toString().replaceAll("\"", ""));

		if (person.has("nickName"))
			p.setNickName(person.get("nickName").toString().replaceAll("\"", ""));

		if (propertyValues.containsKey("firstname"))
			p.setFirstName(propertyValues.get("firstname"));

		if (propertyValues.containsKey("lastname"))
			p.setLastName(propertyValues.get("lastname"));

		if (propertyValues.containsKey("dob"))
			p.setDateOfBirth(propertyValues.get("dob"));

		if (propertyValues.containsKey("nickname"))
			p.setNickName(propertyValues.get("nickname"));
	}

	/**
	 * viewing all person data
	 */
	public static void viewAllPersons() {

		JsonArray personList = getPersonList();

		if (personList.size() > 0) {

			personList.forEach(person -> parsePersonObject((JsonObject) person));
		} else {
			System.out.println("No Person data exist");
		}
	}

	/**
	 * viewing a specific id person data
	 * 
	 * @param propertyValues
	 */
	public static void viewPerson(HashMap<String, String> propertyValues) {

		if (propertyValues.containsKey("id")) {

			final String id = propertyValues.get("id");

			JsonArray list = getPersonList();

			JsonArray newL = new JsonArray();

			list.forEach(person -> {

				JsonObject p = (JsonObject) person;

				if (p.get("id").toString().equals("\"" + id + "\"")) {

					parsePersonObject((JsonObject) person);

					newL.add(person);
				}
			});

			if (newL.size() == 0)
				System.out.println("Person with ID " + id + " does not exist");
		} else
			System.out.println("id field dowsn't exist \\nSyntax :person view -id ID");
	}

	/**
	 * getting all the person data from the file
	 * 
	 * @return
	 */
	public static JsonArray getPersonList() {

		JsonArray list = new JsonArray();

		try {

			JsonParser jsonParser = new JsonParser();
			File file = new File("PersonsData.json");
			file.createNewFile();
			FileReader reader = new FileReader(file);
			// Read JSON file
			Object obj = jsonParser.parse(reader);

			if (!(obj instanceof JsonNull))
				list = (JsonArray) obj;

		} catch (JsonIOException | IOException e) {
			e.printStackTrace();
		}

		return list;
	}

	/**
	 * Retrieving and storing data
	 * 
	 * @param propertyValues
	 * @param p
	 */
	public static void enterValue(HashMap<String, String> propertyValues, Person p) {

		String id = "0";

		JsonArray personList = getPersonList();

		for (JsonElement person : personList) {

			Address a = new Address();

			JsonObject ad = (JsonObject) person;

			a.setId(ad.get("id").toString().replaceAll("\"", ""));

			id = ad.get("id").toString().replaceAll("\"", "");
		}

		p.setId("" + (Integer.parseInt(id) + 1));

		if (propertyValues.containsKey("firstname")) {
			p.setFirstName(propertyValues.get("firstname"));
		}
		if (propertyValues.containsKey("lastname")) {
			p.setLastName(propertyValues.get("lastname"));
		}
		if (propertyValues.containsKey("dob")) {
			p.setDateOfBirth(propertyValues.get("dob"));
		}
		if (propertyValues.containsKey("nickname")) {
			p.setNickName(propertyValues.get("nickname"));
		}
	}

	/**
	 * 
	 * @param keyValueString
	 * @return
	 */
	public static String[] getKeyValue(String keyValueString) {

		String[] keyValue = keyValueString.split(" ");

		if (keyValue.length == 2) {

			keyValue[1] = keyValue[1].replaceAll("�", "");
			keyValue[1] = keyValue[1].replaceAll("�", "");
			keyValue[1] = keyValue[1].replaceAll("\"", "");
			return keyValue;
		} else if (keyValue.length > 2) {

			String[] temp = new String[2];

			temp[0] = keyValue[0];

			temp[1] = "";

			for (int i = 1; i < keyValue.length; i++) {

				keyValue[i] = keyValue[i].replaceAll("�", "");
				keyValue[i] = keyValue[i].replaceAll("�", "");
				keyValue[i] = keyValue[i].replaceAll("\"", "");
				temp[1] += keyValue[i] + " ";
			}
			return temp;
		} else
			return new String[2];
	}

	/**
	 * validates the entry being created.
	 * 
	 * @return
	 */
	public static boolean[] validEntry(Person p) {

		boolean[] propertyNum = new boolean[5];

		propertyNum[0] = true;

		propertyNum[1] = validateName(p.getFirstName());

		propertyNum[2] = validateName(p.getLastName());

		propertyNum[3] = validateDOB(p.getDateOfBirth());

		propertyNum[4] = validateNickName(p.getNickName());

		return propertyNum;
	}

	/**
	 * name validation
	 * 
	 * @param name
	 * @return
	 */
	public static boolean validateName(String name) {

		if (name != null && !name.isEmpty() && !name.isBlank()) {
			for (int i = 0; i < name.length(); i++) {
				if (Character.isDigit(name.charAt(i)))
					return false;
			}

			JsonArray list = getPersonList();

			for (JsonElement person : list) {

				JsonObject p = (JsonObject) person;

				if (p.get("firstName").toString().equals(name) || p.get("lastName").toString().equals(name))
					return false;
			}

			return true;
		} else
			return false;
	}

	/**
	 * date of birth validation
	 * 
	 * @param dob
	 * @return
	 */
	public static boolean validateDOB(String dob) {

		if (dob != null) {

			Pattern p = Pattern.compile("[0123][0-9]/[01][0-9]/[0-9]*");

			Matcher m = p.matcher(dob);

			if (m.find())
				return true;
			else
				return false;
		} else
			return false;
	}

	/**
	 * nick name validation
	 * 
	 * @param name
	 * @return
	 */
	public static boolean validateNickName(String name) {

		if (name == null) {
			return true;
		} else {
			for (int i = 0; i < name.length(); i++) {
				if (Character.isDigit(name.charAt(i)))
					return false;
			}
			return true;
		}
	}

	/**
	 * parsing and displaying the person data
	 * 
	 * @param person
	 */
	public static void parsePersonObject(JsonObject person) {

		String data = person.toString();

		data = data.replaceAll("[{}\"]", "");
		data = data.replaceAll(",", " \t ");
		data = data.replaceAll(":", " : ");

		System.out.println(data);
		System.out.println();
	}

	public static void searchAndDisplayPersons(JsonArray persons, String searchText) {

		persons.forEach(person -> {

			parsePersonObject((JsonObject) person);
		});

		if (persons.size() == 0)
			System.err.println("No person with \"" + searchText + "\" in there name found");

	}

	/**
	 * searching for a person based on the search text
	 * 
	 * @param searchText
	 */
	public static JsonArray searchPerson(String searchText) {

		JsonArray list = getPersonList();

		JsonArray newL = new JsonArray();

		list.forEach(person -> {

			JsonObject p = (JsonObject) person;

			if (p.get("firstName").toString().toUpperCase().contains(searchText.toUpperCase())
					|| p.get("lastName").toString().toUpperCase().contains(searchText.toUpperCase())) {
				newL.add(p);
			}
		});

		return newL;
	}
}
